# Imports for funcitonality and data visualization
import streamlit as st
from pymongo import MongoClient
from streamlit_extras.switch_page_button import switch_page
from datetime import datetime, timedelta
import pandas as pd
import time
import matplotlib.pyplot as plt

# Establish MongoDB connection
connection_string = st.secrets["connection"]
client = MongoClient(connection_string)
Finances_db = client.Finances
users_collection = Finances_db.users
logs = Finances_db.logs
user = users_collection.find_one({"username": st.session_state.logged_in})

# Check for user logged in: required to use logged in inside the rest of the code
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False

# Calculate the balance to display
doc = users_collection.find_one({"username": st.session_state.logged_in})
if doc:
    balance = doc["balance"]
else:
    st.error("There was an issue. Please sign in again")

tolerance = 1e-6
if abs(balance) < tolerance:
    balance = 0
else:
    balance = round(balance, 2)

if balance > 0:
    color = "green"
elif balance < 0:
    color = "red"
else:
    color = "white"
# HTML/CSS to dynamically change balance color based on positive or negative
st.markdown(f'<div style="color: {color}; text-align: center; font-size: 4rem;"> ${balance}  </div>', unsafe_allow_html=True)

# Columns for alignment/positioning
col1, col2 = st.columns([6, 2])
with col2:
    expenses = st.toggle("Expenses")

# Conditional to display breakdown of expenses or income
if not expenses:
    try:
        col1, col2, col3 = st.columns([2.3, 1, 2])
        with col2:
            st.subheader("Income")
        # Get the last week's data
        one_week_ago = datetime.now() - timedelta(days=7)
        data = logs.find({"type": "Income", "user": st.session_state.logged_in})

        # Columns to display visuals
        col4, col5, col6, col7 = st.columns([0.5, 200, 80, 0.01])
        # Convert to DataFrame
        df = pd.DataFrame(list(data))
        category_sum = df.groupby('category')['amount'].sum()

        fig, ax = plt.subplots()

        # Create the pie chart with themeing similar to streamlit dark mode for a seamless UI
        ax.pie(category_sum, labels=category_sum.index, autopct='%1.1f%%', startangle=90,textprops={'color': 'white'})

        # Set background color for the plot area
        fig.patch.set_facecolor('#0e1117')  # Background color for the entire figure
        ax.set_facecolor('#0e1117')  # Background color

        # Equal aspect ratio ensures that pie is drawn as a circle
        ax.axis('equal')

        # Display the chart 
        with col5:
            st.pyplot(fig, use_container_width=True)
            
        # Display totals
        with col6:
            total_spent = df["amount"].sum()
            st.metric("Total Income:", f"${total_spent.item()}")
            st.dataframe(category_sum)
    # In case of error, prompt user to add transactions, and add spacing below to ensure the UI isn't cramped.
    except Exception as e:
        col1, col2, col3 = st.columns([1.5, 4, 1])
        with col2:
            st.subheader("Add transactions to get started!")
            for i in range(5):
                st.write("  \n\n")
if expenses:
    try:
        col1, col2, col3 = st.columns([2.3, 1, 2])
        with col2:
            st.subheader("Expenses")
            
        # Get the last week's data
        one_week_ago = datetime.now() - timedelta(days=7)
        data = logs.find({"type": "Expense", "user": st.session_state.logged_in})

        # Columns for positiioning and alignment
        col4, col5, col6, col7 = st.columns([0.5, 200, 80, 0.01])
        # Convert to DataFrame
        df = pd.DataFrame(list(data))
        category_sum = df.groupby('category')['amount'].sum()

        fig, ax = plt.subplots()

        # Create the pie chart with themeing similar to streamlit dark mode for a seamless UI
        ax.pie(category_sum, labels=category_sum.index, autopct='%1.1f%%', startangle=90,textprops={'color': 'white'})

        # Set background color for the plot area
        fig.patch.set_facecolor('#0e1117')  # Background color for the entire figure
        ax.set_facecolor('#0e1117')  # Surrounding background color

        # Equal aspect ratio ensures that pie is drawn as a circle
        ax.axis('equal')

        # Display the chart
        with col5:
            st.pyplot(fig, use_container_width=True)

        # Display totals
        with col6:
            total_spent = df["amount"].sum()
            st.metric("Total Expenses:", f"${total_spent.item()}")
            st.dataframe(category_sum)
    # Prompt user to add transactions in case of an error- this is the only error the app has encountered thus far
    except Exception as e:
        col1, col2, col3 = st.columns([1.5, 4, 1])
        with col2:
            st.subheader("Add transactions to get started!")
            for i in range(5):
                st.write("  \n\n")


# Columns for positioning/alignment
col1, col2, col3 = st.columns([1.5, 1, 1])

try:
    with col2:
        # <--------- DOWNLOAD SUMMARY FEATURE ------------------->
        with st.popover("Download Summary", help= "Download a customizable summary of your transactions"):
                st.markdown("Customize your report")
                # Pills options for customization
                time_period = st.pills("Time Frame:", ["Week", "Month", "Year"])
                expenses = st.pills("Expense Types:", ["Rent", "Utilities", "Groceries", "Transportation",
                                                       "Insurance", "Food", "Fun",
                                                       "Travel", "Debt", "Savings/Investments", "Other"], selection_mode="multi")
                income = st.pills("Income Types:", ["Work", "Gifts", "Bonuses", "Refunds", "Rental income", "Other"], selection_mode="multi")
                # Initialize days variable
                days = False
                if time_period == "Week":
                    days = 7
                elif time_period == "Month":
                    days = 31
                elif time_period == "Year":
                    days = 365
                # Use days to filter transactions
                if days:
                    start_date = datetime.now() - timedelta(days=days)
                    end_date = datetime.now()
                    categories = expenses + income
                    pipeline = [
                                    {
                                        "$addFields": {
                                            "date_obj": {
                                                "$dateFromString": {
                                                    "dateString": "$date",
                                                    "format": "%m/%d/%Y"  
                                                }
                                            }
                                        }
                                    },
                                    {
                                        "$match": {
                                            "user": st.session_state.logged_in,
                                            "date_obj": {"$gte": start_date, "$lte": end_date},
                                            "category": {"$in": categories}
                                        }
                                    }
                                ]

                    transactions = logs.aggregate(pipeline)
                    df = pd.DataFrame(list(transactions))
                    df = df.drop(columns=['_id', 'user', 'date_obj'], errors='ignore')
                    download_summary = st.download_button("Download", df.to_csv().encode("utf-8"), file_name="Transaction_Summary.csv", mime="text/csv")
except Exception as e:
    col1, col2, col3 = st.columns([1.5, 4, 1])
    with col2:
        st.subheader("Add transactions to get started!")
        for i in range(5):
            st.write("  \n\n")
try:
    # <---------- BUDGET NOTIFICATION ---------->
    active = user.get("balance_info", {}).get("active", None)

    # Similar filtering process for date, see above for further documentation
    if active:
        budget = user.get("balance_info", {}).get("budget", None)
        duration = user.get("balance_info", {}).get("duration", None)
        expenseType = ["Expense"]
        if duration == "Week":
            days = 7
        elif duration == "Month":
            days = 31
        elif duration == "Year":
            days = 365
        if days:
            start_date = datetime.now() - timedelta(days=days)
            end_date = datetime.now()
            categories = expenses + income
            pipeline = [
                            {
                                "$addFields": {
                                    "date_obj": {
                                        "$dateFromString": {
                                            "dateString": "$date",
                                            "format": "%m/%d/%Y" 
                                        }
                                    }
                                }
                            },
                            {
                                "$match": {
                                    "user": st.session_state.logged_in,
                                    "date_obj": {"$gte": start_date, "$lte": end_date},
                                    "type": {"$in": expenseType}
                                }
                            }
                        ]
    
            expensesBudget = logs.aggregate(pipeline)
            df = pd.DataFrame(list(expensesBudget))
            try:
                spent = df["amount"].sum()
             # The error is typically the user having no transactions in the specified timeframe
            except Exception as e:
                spent = 0
            # Compute amount spent and what that means for their budget, display notification
            if spent > int(budget):
                users_collection.update_one(user, {"$set":{"balance_info.over":True}})
            elif spent < int(budget):
                users_collection.update_one(user, {"$set": {"balance_info.over":False}})
            budget_status = user.get("balance_info", {}).get("over", None)
            if budget_status:
                    st.error(f"You've gone over your budget of \${budget:.2f}, and you've spent ${spent:.2f} in the last {duration.lower()}!")
            else:
                st.success(f"You're within your budget of \${budget:.2f}, and you've spent ${spent:.2f} in the last {duration.lower()}!")
except Exception as e:
    pass

# Blurb about good budgeting 
st.write("""
**Good Budgeting Strategies in High School**

Creating a solid budgeting strategy in high school can set the foundation for strong financial habits later in life. Here are some effective strategies for managing money as a high school student:

1. **Track Your Income and Expenses**: Start by noting all your sources of income, whether from allowances, part-time jobs, or gifts. Then, track where your money goes—whether it's on food, entertainment, school supplies, or other expenses. This helps you see where your money is going and where you can cut back.

2. **Set Financial Goals**: Whether it’s saving for a new gadget, a trip, or just building an emergency fund, having clear financial goals will keep you motivated. Break down your goals into short-term and long-term objectives, and allocate your income accordingly.

3. **Use the 50/30/20 Rule**: A great guideline to follow is the 50/30/20 rule—allocate 50% of your income to needs (like essentials and school supplies), 30% to wants (such as entertainment or hobbies), and 20% to savings or debt repayment.

4. **Open a Savings Account**: Start building a savings habit early by putting aside a portion of your income each month. Consider opening a savings account with no fees and a competitive interest rate to grow your savings over time.

5. **Limit Impulse Spending**: It’s easy to be tempted by small purchases, but limiting impulse spending can have a big impact on your budget. Plan your purchases and avoid spending money you don’t need to. This can also involve avoiding buying things just because they are on sale.

6. **Plan for Unexpected Expenses**: Emergencies happen, so it’s important to set aside some money for unexpected expenses like medical bills, school projects, or sudden transportation costs. A small emergency fund can prevent these surprises from derailing your budget.

By implementing these budgeting strategies, high school students can learn how to manage their finances responsibly, avoid debt, and build good habits that will last throughout their lives.
""")

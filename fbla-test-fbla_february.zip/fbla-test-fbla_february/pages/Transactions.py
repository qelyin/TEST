# Import statements for functionality
import streamlit as st
from pymongo import MongoClient
import pandas as pd
from streamlit_tags import st_tags

# Connect to MongoDB using the connection string from secrets
connection_string = st.secrets["connection"]
client = MongoClient(connection_string)
Finances_db = client.Finances
users_collection = Finances_db.users
logs = Finances_db.logs

# Ensure login state is defined in session state
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False

# Function to create vertical spacing
def create_lines(col, lines):
    for _ in range(lines):
        col.write("\n\n")

# Get current logged-in user
user = st.session_state.logged_in

# UI Setup
col1, col2 = st.columns([20, 5])
with col1:
    st.title("Your Transactions")

with col2:
    create_lines(col2, 2)
    # Toggle to enable/disable edit mode
    edit = st.toggle("Edit mode", key="edit_toggle")

col1, col2 = st.columns([20, 5])
create_lines(col2, 1)

# Filter input using streamlit-tags
with col1:
    filters = st_tags(
        label=" ",
        text="Search transactions...",
        maxtags=20,
        key="filtersKey"
    )
# Button to trigger search
enter_filters = col2.button("Search", key="search_button")

# Fetch transaction data for the logged-in user
data = list(logs.find({'user': st.session_state.logged_in}))

try:
    # Load data into a DataFrame
    df = pd.DataFrame(data)

    # Keep keys for MongoDB consistency
    ids = df['_id']
    users = df['user']

    # Drop keys that don't need to be displayed (but keep them in the data)
    df = df.drop(columns=['_id', 'user', 'date_obj'], errors='ignore')

    # Filtering logic
    if enter_filters:
        if isinstance(filters, str):
            filters = [filters]

        matching_documents = []
        for filter_term in filters:
            regex_pattern = f".*{filter_term}.*"
            query = {
                "$or": [
                    {"name": {"$regex": regex_pattern, "$options": "i"}},
                    {"type": {"$regex": regex_pattern, "$options": "i"}},
                    {"amount": {"$regex": regex_pattern, "$options": "i"}},
                    {"category": {"$regex": regex_pattern, "$options": "i"}},
                    {"date": {"$regex": regex_pattern, "$options": "i"}},
                    {"notes": {"$regex": regex_pattern, "$options": "i"}},
                ],
                "user": st.session_state.logged_in
            }
            matching_documents.extend(list(logs.find(query)))

        if matching_documents:
            # Remove duplicates
            unique_docs = []
            unique_data = []
            for doc in matching_documents:
                if doc not in unique_docs:
                    unique_docs.append(doc)
                    unique_data.append([
                        doc.get('name'),
                        doc.get('type'),
                        doc.get("amount"),
                        doc.get('category'),
                        doc.get('date'),
                        doc.get('notes')
                    ])
            # Load filtered data into DataFrame
            df = pd.DataFrame(unique_data, columns=['Name', 'Type', 'Amount', 'Category', 'Date', 'Notes'])

        else:
            st.warning("None of the items match the given filters. Please try again.")

except Exception as e:
    st.write("No records to show.")

# Edit Mode: Allow user to modify data directly
if edit:
    # Editable table using data_editor
    edited_df = st.data_editor(
        df,
        use_container_width=True,
        hide_index=True,
        disabled=['type', 'category', 'date'],  # Prevent modification of certain fields
        key="data_editor"
    )

    # Save button to update changes in MongoDB
    if st.button("Save Changes", key="save_button"):
        for index, row in edited_df.iterrows():
            # Preserve keys when updating MongoDB
            row['_id'] = ids[index]
            if '_id' in row:
                filter_query = {'_id': row['_id']}
                update_query = {'$set': row.to_dict()}

                # Restore user field (since it was dropped for display)
                update_query["$set"]["user"] = users[index]
                logs.update_one(filter_query, update_query)

else:
    # Display static table in read-only mode
    st.dataframe(df, use_container_width=True, hide_index=True, key="static_table")

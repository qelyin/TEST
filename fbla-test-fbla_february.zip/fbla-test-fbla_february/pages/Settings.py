# Import statements for functionality
import streamlit as st
from pymongo import MongoClient
import requests
from streamlit_extras.switch_page_button import switch_page
import bcrypt
import random
import smtplib
from email.mime.text import MIMEText

# Initialize session state variables for future use
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'change_user' not in st.session_state:
    st.session_state.change_user = False
if 'change_password' not in st.session_state:
    st.session_state.change_password = False
if 'send_code' not  in st.session_state:
    st.session_state.send_code = False
if 'verification_code' not in st.session_state:
    st.session_state.verification_code = False
if 'messages' not in st.session_state:
    st.session_state.messages = []
if "email_verified" not in st.session_state:
    st.session_state.email_verified = False

# Establish MondoDB connection
connection_string = st.secrets["connection"]
client = MongoClient(connection_string)
Finances_db = client.Finances
users_collection = Finances_db.users
logs = Finances_db.logs
user = users_collection.find_one({"username": st.session_state.logged_in})

def verify_email(email):
    """
    Send a verification email to the user.
    
    Args:
        email (str): User's email address.
    
    Returns:
        bool: True if the email is sent successfully, False otherwise.
    """
    code = random.randint(10000, 999999)
    st.session_state.verification_code = str(code)
    try:
        msg = MIMEText(f"Your BudgetBuddy verification code is: {code}")
        msg["From"] = "bbuddy.verify@gmail.com"
        msg["To"] = email
        msg["Subject"] = "BudgetBuddy Password Reset"

        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login("bbuddy.verify@gmail.com", "gyxi jnrc juzc oqfn")
        server.sendmail("bbuddy.verify@gmail.com", email, msg.as_string())
        server.quit()

        st.success("Email sent")
        return True

    except Exception as e:
        st.error("Your account could not be verified. Please try again later.")
        st.write(e)

st.title("Settings")

# <--------------- GETTING STARTED --------------->
with st.expander("Getting Started"):
    st.subheader("Getting started with BudgetBuddy is simple!")
    st.write("After creating an account, head over to the 'Manage Transactions' screen")
    st.write("After that, add transactions to get started. You can select the type of income/expense, and add any notes you want to remember")
    st.write("To view your transactions, navigate to the transactions page. There, you recieve a complete summary of your transactions and the option to edit.")
    st.write("Navigating to the balance page, you can view your expenses and incomes through a pie chart, as well as recieve useful budgeting tips and download specific data.")
    st.write("Have questions about financing? Talk to our chatbot, and by selecting the mode 'analyze', you can even recieve customized feedback!")
# <--------------- CHANGE USERNAME --------------->
with st.expander("Username"):
    # User will be the logged in user
    st.write(f"Username: {st.session_state.logged_in}")
    if st.button("Change Username"):
        st.session_state.change_user = True
    if st.session_state.change_user:
        pwd = st.text_input("Password: ")
        new_user = st.text_input("New Username: ")
        if st.button("Submit"):
            update = {}
            update["$set"] = {"username": new_user}
            # Using password for verification, ensure it matches with stored, hashed password
            if bcrypt.checkpw(pwd.encode('utf-8'), user.get("password")):
                users_collection.update_one({"username": st.session_state.logged_in}, update)
                st.session_state.logged_in = new_user
                st.session_state.change_user = False
# <--------------- RESET PASSWORD --------------->
with st.expander("Reset Password"):
    old_pwd = st.text_input("Old password: ")
    # Check entered password with stored password
    if st.button("Confirm") and bcrypt.checkpw(old_pwd.encode('utf-8'), user["password"]):
        st.session_state.change_password = True

    # Display new fields if old password was correct
    if st.session_state.change_password == True:
        new_pwd = st.text_input("New Password: ")
        conf_pwd = st.text_input("Confirm Password: ")
        if st.button("Confirm", key="confirm2"):
            if conf_pwd == new_pwd:
                # Update password 
                update = {}
                update["$set"] = {"password": bcrypt.hashpw(new_pwd.encode('utf-8'), bcrypt.gensalt())}
                users_collection.update_one({"username": st.session_state.logged_in}, update)
                st.success("Password reset!")
# <--------------- BALANCE --------------->
with st.expander("Balance"):
    # Allow users to input a new balance, and update balance for user in database
    st.write(f"Current balance: {user["balance"]}")
    col1, col2 = st.columns([4, 1])
    with st.form("balance_form", border=False):
        new_bal = st.number_input("New Balance: ")
        if st.form_submit_button("Confirm"):
            update = {}
            update["$set"] = {"balance": int(new_bal)}
            users_collection.update_one({"username": st.session_state.logged_in}, update)

# <--------------- BUDGET --------------->
with st.expander("Budget"):
    # Encapsulate inputs in a form
    with st.form("Set your budget!", border=False):
        budget = st.number_input("Budget: ")
        duration = st.selectbox("Duration", ("Week", "Month", "Year"))
        active = st.toggle("Active?") # Only display notification if budget is active
        # Update user log in database to reflect budget choices
        if st.form_submit_button("Confirm"):
            users_collection.update_one( {"username": st.session_state.logged_in},  
        {"$set": {"balance_info": {"budget": budget, "active": active, "over": False, "duration": duration}}})
# <--------------- ABOUT --------------->
with st.expander("About"):
    st.write("BudgetBuddy is a website developed by Dhun Pandya to encourage high schoolers to pursue educated financial endeavours. \n"
             "Keeping track of finances can be difficult, and BudgetBuddy is here to help. With pie charts, tabular data, and downloadable summaries, finances remain completely under the students control.")


logout = st.button("Log Out")

# Reset all variables on logout
if logout:
    st.session_state.logged_in = False
    st.session_state.email_verified = False
    st.session_state.messages = []
    st.session_state.change_passwoed = False
    st.rerun()

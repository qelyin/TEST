# Import statements for functionality
import streamlit as st
from pymongo import MongoClient
import requests
from streamlit_extras.switch_page_button import switch_page
import pandas as pd
from bson import ObjectId

# Establish MongoDB connection
connection_string = st.secrets["connection"]
client = MongoClient(connection_string)
Finances_db = client.Finances
users_collection = Finances_db.users
logs = Finances_db.logs


def create_lines(col, lines):
    """
    Create lines in the specified column

    Args:
        col (str): Column to create new line in
        lines (int): number of new lines to create
        
    Returns:
        None: Adds lines to specified column, returns nothing
    """
    for i in range(lines):
        col.write(" \n\n")

# Check for login- necessary to ensure usability of the logged_in variable in the rest of the code.
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False

# Columns for position/alignment
col1, col2, col3 = st.columns([1,1.7,1])
with col2:
    # Display for tabs to center align text
    css = st.markdown("""
        <style>
            .stTabs [data-baseweb="tab-list"] {
                gap: 5vw;
                justify-content: center;
            }
                
            .stTabs [data-baseweb="tab"] {
                height: 50px;
                white-space: pre;
                font-size: 100px;
            }
            .stTabs [data-baseweb="tab"] button {
                font-size: 200px;
            }
            .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
                font-size:1rem;
            }
        </style>
    """, unsafe_allow_html=True)

# Create add and remove tabs
add, remove = st.tabs(["Add Transactions", "Delete Transactions"])

# <--------------- ADD TRANSACTIONS MENU --------------->
with add:
    st.title("Add Transaction")
    try:
        name = st.text_input("Transaction Name")
        transaction_type = st.selectbox(label="Transaction type", options=['Income', 'Expense'])
        # Preset subcategories for income and expense to dynamically adjust category input based on type input
        income_categories = ["Work", "Gifts", "Bonuses", "Refunds", "Rental income", "Other"]
        expense_categories = ["Rent", "Utilities", "Groceries", "Transportation",
                              "Insurance", "Food", "Fun",
                              "Travel", "Debt", "Savings/Investments", "Other"]
        # Display preselected subcategories in category select
        if transaction_type == "Income":
            category = st.selectbox("Category", income_categories)
        else:
            category = st.selectbox("Category", expense_categories)
        amount = st.number_input("Amount")
        date = st.date_input("Date:", value=None)
        notes = st.text_input("Notes: ")
    
        submit = st.button('Submit')

        # Compile the data into a JSON doc
        if submit:
            transaction = {
                "user": st.session_state.logged_in,
                "name": name,
                "type": transaction_type,
                "amount": amount,
                "category": category,
                "date": date.strftime('%m/%d/%Y'),
            "notes": notes
            }
            # Insert the data into the logs cluster
            logs.insert_one(transaction)
            # Find logged in user
            doc = users_collection.find_one({"username": st.session_state.logged_in})
            if doc:
                # Adjust balance based on added transaction
                balance = doc["balance"]
                if transaction_type == "Expense":
                    amount = -abs(amount)
                new_balance = balance + amount
                users_collection.update_one({"username": st.session_state.logged_in},
                                            {
                                                "$set":{
                                                    "balance": new_balance
                                                }
                                            })
                st.success("Transaction Added!")
    # Communicate issue- most commonly user didn't fill out date, type, or category field.
    except Exception as e:
        st.error("There was an issue. Did you fill out all the fields?")

# <--------------- REMOVE TRANSACTIONS MENU --------------->
with remove:
    try:
        user = st.session_state.logged_in
        col1, col2 = st.columns([3, 1])
        with col1:
            st.title("Delete Transactions")
        data = list(logs.find({'user': st.session_state.logged_in}))
        df = pd.DataFrame(data)
        df = df.drop(columns=['user'])
        df["Delete?"] = False
        
        # Create editable dataframe- user cannot edit entries, but edit the column to allow for deletion
        edited_df = st.data_editor(df, disabled=['_id', 'type', 'category', 'amount', 'notes', 'date', 'name'],
                       hide_index=True)
        with col2:
            create_lines(col2, 2)
            delete = st.button("Delete Selected")
        if delete:
            for index, row in edited_df.iterrows():
                if row["Delete?"] == True:
                    id = row["_id"]
                    trans_type = row['type']
                    amount = row["amount"]
                    update = {}
                    user_reference = users_collection.find_one({"username": user})
                    balance = user_reference["balance"]
                    # Adjust user balance based on deletion
                    if trans_type == "Expense":
                        balance += amount
                        update["$set"] = {"balance": balance}
                        users_collection.update_one(user_reference, update)
                    else:
                        balance -= amount
                        update["$set"] = {"balance": balance}
                        users_collection.update_one(user_reference, update)
                    query = logs.find_one({'_id': ObjectId(id)})
                    logs.delete_one(query)
    # Most common error is lack of transaction data
    except Exception as e:
        st.write("No records to show.")



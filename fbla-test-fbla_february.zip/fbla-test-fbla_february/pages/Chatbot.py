# Import statements for functionality
import streamlit as st
from pymongo import MongoClient
import openai

# Connect to MongoDB
connection_string = st.secrets["connection"]
client = MongoClient(connection_string)
finances_db = client.Finances
users_collection = finances_db.users
logs = finances_db.logs
user = users_collection.find_one({"username": st.session_state.get("logged_in")})

# OpenAI API Key
client = openai.Client(api_key=st.secrets["gpt_key"])

# Initialize state variables
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "messages" not in st.session_state:
    st.session_state.messages = []
if "mode" not in st.session_state:
    st.session_state.mode = "general"  # Default to general chat

# System message for context
SYSTEM_MESSAGE = {
    "role": "system",
    "content": (
        "Your name is BudgetBot. You are a chatbot on the website for a program called BudgetBuddy- it helps high schoolers keep track of financial information. "
        "There's a login page with login, signup, and forgot password functionalities. Email is used to reset password, and signup requires an email. "
        "After logging in, they see a settings page with the ability to change their username, password, or current balance. "
        "The manage transactions page allows users to add and delete transactions. The balance page allows users to view a pie chart of the incomes or expenses, "
        "download customizable summaries, and general financial tips. The transactions page shows a table of all transactions, "
        "and there's an edit toggle to let you edit your transactions—you can't edit the category and income/expense though. You can also set a budget in the settings menu,"
        "and the balance page will display your budget and current spending based on what you enter"
    )
}

# Title and Caption
st.title("BudgetBot")
st.caption("Powered by OpenAI's ChatGPT")

# Chat Containers
inputs = st.container()
history = st.container(border=True, height=500)
chat = st.container(border=False)

# Button options for mode switching
with inputs:
    col1, col2 = st.columns([4, 3])

    def update_mode(select):
        """
        Update session state to correspond with user mode selection
            
        Args:
            select (str): User's mode selection.
            
        Returns:
            None: Updates session state, no value is returned.
        """
        if select == "General":
            st.session_state.mode = "general"
        if select == "Analyze":
            st.session_state.mode = "analyze"

    with col1:
        options = ["General", "Analyze"]
        selection = st.pills(
            "Mode:",
            options,
            selection_mode="single",
            help="General chat for normal conversations, analyze to send transaction history for customized feedback"
        )

    if selection:
        update_mode(selection)

# Display chat history (skip system messages)
with history:
    for message in st.session_state.messages:
        if message["role"] != "system":
            with st.chat_message(message["role"]):
                st.markdown(message["content"])

# Handle user input
if user_input := st.chat_input("Ask a question..."):
    if st.session_state.mode == "analyze":
        # Fetch user's transactions from MongoDB
        transactions = logs.find({"user": st.session_state.logged_in})
        transaction_text = "\n".join(
            f"Date: {t['date']}, Type: {t['type']}, Amount: ${t['amount']}, "
            f"Category: {t['category']}, Notes: {t.get('notes', 'N/A')}"
            for t in transactions
        )
        balance = user.get('balance', 0)
        
        # Send financial data through the system role 
        TRANSACTION = {
            "role": "system",
            "content": (
                f"Here are my recent transactions:\n{transaction_text}.\n"
                f"My current balance is ${balance} after accounting for expenses and incomes.\n"
            )
        }
        

    st.session_state.messages.append({"role": "user", "content": user_input})

    # Send entire message history to ensure conversation relevancy, send context and transaction data if analyzing
    if st.session_state.mode == "analyze":
        messages = [SYSTEM_MESSAGE] + [TRANSACTION] + st.session_state.messages
    # Send message history for relevancy, and system message for context- no transaction data because user selected general mode
    else:
        messages = [SYSTEM_MESSAGE] + st.session_state.messages

    # Spinner to make loading feel less boring
    with st.spinner("Thinking..."):
        # Send message to ChatGPT Model 3.5 Turbo
        completion = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages
        )
        response = completion.choices[0].message.content

    # Save response to session state
    st.session_state.messages.append({"role": "assistant", "content": response})

    # Display AI response
    with history:
        with st.chat_message("assistant"):
            st.markdown(response)

    st.rerun()

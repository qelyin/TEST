# Documentation utilized from Streamlit's library and OpenAI's API
# Import statements for key functionality
import streamlit as st
from pymongo import MongoClient
import bcrypt
import smtplib
from email.mime.text import MIMEText
import random
import time

# Establish MongoDB connection using Streamlit secrets
connection_string = st.secrets["connection"]
google_key = st.secrets["google_key"]
client = MongoClient(connection_string)
Finances_db = client.Finances
users_collection = Finances_db.users

# Get list of existing usernames (excluding admin)
usernames = [doc['username'] for doc in users_collection.find()]
usernames = [user for user in usernames if user != "admin"]

# Initialize session state for login status
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False


def create_account(name, username, pwd, email, balance):
    """
    Create a new user account and store it in the database.
    
    Args:
        name (str): User's full name.
        username (str): Desired username.
        pwd (str): Password.
        email (str): Email address for verification.
        balance (float): Initial balance.
    
    Returns:
        bool: True if account creation is successful, False otherwise.
    """
    add_input = {
        'username': username,
        'password': bcrypt.hashpw(pwd.encode('utf-8'), bcrypt.gensalt()),
        'email': email,
        'name': name,
        'balance': balance
    }

    # Determine if username is unique
    if users_collection.find_one({'username': username}):
        st.error("Username unavailable")
        return False
        
    # Ensure a valid username nad password are inputted
    if len(username) > 0 and len(pwd) >= 8 and username not in usernames:
        users_collection.insert_one(add_input)
        st.success("Your account has successfully been created!")
        return True

    # Ask for a password of proper length
    elif len(username) > 0 and len(pwd) <= 8:
        st.error("Password must be at least 8 characters")
        return False
        
    # Inform user of usrname being taken
    elif username in usernames:
        st.error("Username already exists")
        return False
    else: # Any other issue with user inputs
        st.warning("Please create your username and password.")
        return False

def verify_email(email):
    """
    Send a verification email to the user.
    
    Args:
        email (str): User's email address.
    
    Returns:
        bool: True if the email is sent successfully, False otherwise.
    """
    if email == "":
        st.error("Please enter an email.")
        return False
    
    code = random.randint(10000, 999999)
    st.session_state.verification_code = str(code)
    
    try:
        msg = MIMEText(f"Your BudgetBuddy verification code is: {code}")
        msg["From"] = "bbuddy.verify@gmail.com"
        msg["To"] = email
        msg["Subject"] = "BudgetBuddy Verification Code"

        # SMTP setup for sending the email
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login("bbuddy.verify@gmail.com", google_key)
        server.sendmail("bbuddy.verify@gmail.com", email, msg.as_string())
        server.quit()

        st.success("Email sent")
        return True

    except Exception as e:
        st.error("Your account could not be verified. Please try again later.")
        return False

def login_page():
    """
    Display the login, sign-up, and password recovery interface.
    """
    col1, col2, col3 = st.columns([1, 1.7, 1])
    with col2:
        st.title("Budget Buddy")

    # Custom CSS for styling
    st.markdown(
        """
        <style>
            .stTabs [data-baseweb="tab-list"] {
                gap: 5vw;
                justify-content: center;
            }
            .stTabs [data-baseweb="tab"] {
                height: 50px;
                white-space: pre;
                font-size: 100px;
            }
            .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
                font-size:1rem;
            }
        </style>
        """, unsafe_allow_html=True
    )

    # Create tabs for login, sign-up, and password recovery
    login, signup, forgot_pass = st.tabs(["Log in", "Sign up", "Forgot Password"])

    # ---------------------- LOGIN ----------------------
    with login:
        st.subheader("Login")
        input_user = st.text_input("Username:")
        input_pwd = st.text_input("Password:", type="password")

        if st.button("Log in"):
            user_query = {'username': input_user}
            login_doc = users_collection.find_one(user_query)

            # Check the hashed password against the input password
            if login_doc and bcrypt.checkpw(input_pwd.encode('utf-8'), login_doc.get('password')):
                st.success("Logged in successfully!")
                st.session_state.logged_in = input_user
                st.rerun()
            else:
                st.error("Incorrect username or password.")

    # ---------------------- SIGN UP ----------------------
    with signup:
        st.subheader("Sign Up")
        input_name = st.text_input("Name:")
        input_user = st.text_input("Username:*")
        input_email = st.text_input("Email:*")
        input_pwd = st.text_input("Password:*", type="password")
        input_balance = st.number_input("Current Balance:")

        # Session state for email verification: required to ensure fields appear and disappear dynamically
        if "email_verified" not in st.session_state:
            st.session_state.email_verified = False

        # Display verification options if email hasn't been verified
        if not st.session_state.email_verified:
            if st.button("Send Verification Code"):
                # Ensure required fields have been filled
                if input_name and input_email and input_pwd:
                    if verify_email(input_email):
                        st.session_state.awaiting_verification = True
                else:
                    st.error("Please fill out the required fields.")

        if st.session_state.get("awaiting_verification"):
            verification_input = st.text_input("Enter Verification Code:")
            if st.button("Verify"):
                if verification_input == st.session_state.get("verification_code"):
                    st.success("Email verified! You can now complete sign-up.")
                    st.session_state.email_verified = True
                    st.session_state.awaiting_verification = False
                else:
                    st.error("Incorrect verification code. Please try again.")

        if st.session_state.email_verified:
            if st.button("Complete Sign-Up"):
                if create_account(input_name, input_user, input_pwd, input_email, input_balance):
                    st.success("Your account has successfully been created! You can now log in.")

    # ---------------------- FORGOT PASSWORD ----------------------
    with forgot_pass:
        st.subheader("Forgot Password")
        
        # Initialize session states if they don't exist
        if "email_verified_password" not in st.session_state:
            st.session_state.email_verified_password = False
        if "password_reset_complete" not in st.session_state:
            st.session_state.password_reset_complete = False
        
        # Reset form if password reset was completed
        if st.session_state.password_reset_complete:
            st.session_state.awaiting_verification_password = False
            st.session_state.reset_pwd = False
            st.session_state.password_reset_complete = False
            st.session_state.pop("verification_code", None)
            st.rerun()
        
        forgot_pass_user = st.text_input("Username:", key="forgot_pass_user")
        forgot_pass_email = st.text_input("Email:", key="forgot_pass_email")
        
        if st.button("Send Verification Code", key="verify_code_password"):
            user = users_collection.find_one({"username": forgot_pass_user})
            if user and forgot_pass_email == user["email"]:
                if verify_email(forgot_pass_email):
                    st.session_state.awaiting_verification_password = True
                    st.success("Verification code sent!")
                    st.rerun()
            else:
                st.error("Invalid username or email.")
                
        if st.session_state.get("awaiting_verification_password"):
            verification_input_password = st.text_input("Enter Verification Code:", key="verification_code_pwd")
            if st.button("Verify", key="verify_btn"):
                if verification_input_password == st.session_state.get("verification_code"):
                    st.session_state.reset_pwd = True
                    st.success("Code verified!")
                    st.rerun()
                else:
                    st.error("Incorrect verification code. Please try again.")
                    
        if st.session_state.get("reset_pwd"):
            new_pwd = st.text_input("New Password:", type="password", key="new_password")
            if st.button("Confirm", key="confirm_pwd"):
                update = {"$set": {"password": bcrypt.hashpw(new_pwd.encode('utf-8'), bcrypt.gensalt())}}
                users_collection.update_one({"username": forgot_pass_user}, update)
                st.success("Password updated successfully!")
                # Set completion flag to true, will reset on next rerun
                st.session_state.password_reset_complete = True
                # Wait briefly to show success message before resetting
                time.sleep(2)
                st.rerun()


# ---------------------- PAGE DEFINITIONS ----------------------
home = st.Page(login_page, title="Home")
add_transactions = st.Page("pages/Manage Transactions.py", title="Manage Transactions")
balance = st.Page("pages/Balance.py", title="Balance")
transactions = st.Page("pages/Transactions.py", title="Transactions")
settings = st.Page("pages/Settings.py", title="Settings")
ai_assistant = st.Page("pages/Chatbot.py", title="BudgetBot")

# ---------------------- NAVIGATION ----------------------
if st.session_state.logged_in:
    pages = {
        "Finances": [balance, add_transactions, transactions, ai_assistant],
        "Your Account": [settings]
    }
else:
    pages = {"Main": [home]}

pg = st.navigation(pages)
pg.run()

This is the finalized version of the project BudgetBuddy, created for FBLA's 2024 to 2025 school year. The purpose of BudgetBuddy is to aide high schoolers with financing and budget management, 
through a meaningful and intuitive interface.
Users can get started by visiting budgetbud.streamlit.app, and creating an account and transactions of different types.
To get help with BudgetBuddy, users can contact bbuddy.verify@gmail.com, or ask Budgetbot.
Dhun Pandya is the creator and only contributor to the project.
